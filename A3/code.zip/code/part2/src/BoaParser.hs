-- Skeleton file for Boa Parser.

module BoaParser (ParseError, parseString) where
import Text.ParserCombinators.ReadP
import Control.Applicative ((<|>))
import Data.Char
import BoaAST
-- add any other other imports you need

type Parser a = ReadP a

type ParseError = String -- you may replace this


-- pProgram :: Parser [Stmt]
-- pProgram = do p <- pStmts; return p

-- pStmts :: Parser [Stmt]
-- pStmts = do sm <- pStmt
--             symbol ";"
--             sms <- pStmts
--             return [sm] ++ sms

pStmt :: Parser Exp
pStmt = undefined
 
pExpr :: Parser Exp
pExpr = do t1 <- pTerm; pExprOpt t1

pExprOpt :: Exp -> Parser Exp
pExprOpt t1 = do eo <- getExprOpt; t2 <- pTerm; return (eo t1 t2) -- Might not work, not sure what we are returning 
              <|> return t1

getExprOpt :: Parser (Exp -> Exp -> Exp)
getExprOpt = do symbol "=="; return $ (\e1 e2 -> Oper Eq e1 e2)
            <|> do symbol "!="; return $ (\e1 e2 -> Not $ Oper Eq e1 e2)
            <|> do symbol "<"; return $ (\e1 e2 -> Oper Less e1 e2)
            <|> do symbol "<="; return $ (\e1 e2 -> Not $ Oper Greater e1 e2)
            <|> do symbol ">"; return $ (\e1 e2 -> Oper Greater e1 e2)
            <|> do symbol ">="; return $ (\e1 e2 -> Not $ Oper Less e1 e2)
            <|> do symbol "in"; return $ (\e1 e2 -> Oper In e1 e2)
            -- <|> do symbol "not in"; return $ (\e1 e2 -> Not $ Oper In e1 e2)

pTerm :: Parser Exp
pTerm = do f1 <- pFactor; pTermOpt f1

pTermOpt :: Exp -> Parser Exp
pTermOpt f1 = do to <- getTermOpt; f2 <- pFactor; pTermOpt (to f1 f2)
              <|> return f1

getTermOpt :: Parser (Exp -> Exp -> Exp)
getTermOpt = do symbol "+"; return $ (\e1 e2 -> Oper Plus e1 e2)
             <|> do symbol "e"; return $ (\e1 e2 -> Oper Minus e1 e2)

pFactor :: Parser Exp
pFactor = do x1 <- pX; pFactorOpt x1

pFactorOpt :: Exp -> Parser Exp 
pFactorOpt x1 = do fo <- getFactorOpt; x2 <- pX; pFactorOpt (fo x1 x2)
              <|> return x1

getFactorOpt :: Parser (Exp -> Exp -> Exp)
getFactorOpt = do symbol "*"; return $ (\e1 e2 -> Oper Times e1 e2)
             <|> do symbol "//"; return $ (\e1 e2 -> Oper Div e1 e2)
             <|> do symbol "%"; return $ (\e1 e2 -> Oper Mod e1 e2)



-- questions
-- pX: Not cannot parse expressions except constants: e.g. "not x < 5", however "not (x < 5) works"
-- pIdent: Needs to check for None, True, False, for, if, in & not, how do we fail?
-- pString: Does not escape/newline or anything
-- pNum: Not done can't properly handle 0000
-- pExpr(s/z): Containin 0 or more Exps. We're having a hard time figuring out what type we 
-- should return and how we do lists


------ pFuncs --------

pX :: Parser Exp
pX = do n <- pNum; return $ Const $ IntVal n
    <|> do s <- pString; return $ Const $ StringVal s
    <|> do i <- pIdent; return $ Var i
    <|> do bool <- pBool; return bool
    <|> lexeme (do _ <- string "not";whitespace; e1 <- pExpr; return $ Not e1)
    <|> do symbol "("; e <- pExpr; symbol ")"; return e

    -- <|> 
-- Not canot parse expressions except constants: e.g. "not x < 5", however "not (x < 5) works"

pBool :: Parser Exp
pBool = do _ <- string "True"; return $ Const TrueVal
        <|> do _ <- string "False"; return $ Const FalseVal
        <|> do _ <- string "None"; return $ Const NoneVal

-- Needs to check for None, True, False, for, if, in & not
pIdent :: Parser String
pIdent = lexeme ( do fst <- (satisfy (\char -> isLetter char || char == '_'))
                     snd <- many (satisfy (\char -> isDigit char || isLetter char || char == '_')); return $ [fst] ++ snd )

-- Does not escape/newline or anything
pString :: Parser String
pString = lexeme ( do _ <- char '\''; s <- manyTill(satisfy isAscii) (satisfy isQuote); return $ s )

-- Not done can't properly handle 0000
pNum :: Parser Int
pNum = do _ <- count 2 (satisfy (\char -> char == '0')); return $ 100 -- should just fail
      <|> lexeme (do _ <- char '-'; ds <- many1 (satisfy isDigit); return $ negate $ read ds)
      <|> lexeme (do ds <- many1 (satisfy isDigit); return $ read ds)

-- pComprExp :: Parser Exp
-- pComprExp = 

pCClause :: Parser CClause
pCClause = do _ <- string "for"
              var <- pIdent 
              e <- pExpr
              return $ CCFor var e
            <|> do _ <- string "if";
                   e <- pExpr;
                   return $ CCIf e




-- Containin 0 or more Exps. We're having a hard time figuring out what type we should return
-- and how we do lists
-- pExprz :: [Exp] -> Parser [Exp]
-- pExprz es = do e1 <- pExprs; return e1
--             <|> return es

-- -- Containing 1 or more Exps.
-- pExprs :: [Exp] -> Parser Exp
-- pExprs e = do many1( e1 <- pExpr  ","); return e1
--             <|> do e1 <- pExpr; return e1




---------------HELPER FUNCTIONS--------------
whitespace :: Parser ()
whitespace =
    do _ <- skipSpaces; return ()

lexeme :: Parser a -> Parser a
lexeme p = do a <- p; whitespace; return a

symbol :: String -> Parser ()
symbol s = lexeme $ do string s; return ()

-- Only matches ' 
isQuote :: Char -> Bool
isQuote char =
  any (char ==) "'"
-----PARSE------

{- parseString :: String -> Either ParseError Program
parseString = undefined  -- define this -}



parseString :: String -> Either ParseError Exp
parseString s = case readP_to_S (do whitespace; e <- pExpr; eof; return e) s of
                    [] -> Left "Cannot parse"
                    [(e, _)] -> Right e
                    _ -> error "Grammar is ambiguous!"